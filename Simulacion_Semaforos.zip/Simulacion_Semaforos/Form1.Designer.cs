﻿namespace Simulacion_Semaforos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBoxrojo1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxamarillo1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxverde1 = new System.Windows.Forms.PictureBox();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.btnDetener = new System.Windows.Forms.Button();
            this.pictureBoxrojo2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxamarillo2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxverde2 = new System.Windows.Forms.PictureBox();
            this.btnApagar = new System.Windows.Forms.Button();
            this.txtRojo = new System.Windows.Forms.TextBox();
            this.txtAmarillo = new System.Windows.Forms.TextBox();
            this.txtVerde = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBoxSemaforo1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSemaforo2 = new System.Windows.Forms.PictureBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.pictureBoxverde3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxamarillo3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxrojo3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSemaforo3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxverde4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxamarillo4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxrojo4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxSemaforo4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo4)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxrojo1
            // 
            this.pictureBoxrojo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxrojo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxrojo1.Location = new System.Drawing.Point(303, 109);
            this.pictureBoxrojo1.Name = "pictureBoxrojo1";
            this.pictureBoxrojo1.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxrojo1.TabIndex = 2;
            this.pictureBoxrojo1.TabStop = false;
            // 
            // pictureBoxamarillo1
            // 
            this.pictureBoxamarillo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxamarillo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxamarillo1.Location = new System.Drawing.Point(303, 153);
            this.pictureBoxamarillo1.Name = "pictureBoxamarillo1";
            this.pictureBoxamarillo1.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxamarillo1.TabIndex = 3;
            this.pictureBoxamarillo1.TabStop = false;
            // 
            // pictureBoxverde1
            // 
            this.pictureBoxverde1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxverde1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxverde1.Location = new System.Drawing.Point(303, 197);
            this.pictureBoxverde1.Name = "pictureBoxverde1";
            this.pictureBoxverde1.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxverde1.TabIndex = 4;
            this.pictureBoxverde1.TabStop = false;
            // 
            // btnIniciar
            // 
            this.btnIniciar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnIniciar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIniciar.Location = new System.Drawing.Point(200, 453);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(102, 34);
            this.btnIniciar.TabIndex = 8;
            this.btnIniciar.Text = "Iniciar";
            this.btnIniciar.UseVisualStyleBackColor = false;
            this.btnIniciar.Click += new System.EventHandler(this.btnIniciar_Click);
            // 
            // btnDetener
            // 
            this.btnDetener.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnDetener.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDetener.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetener.Location = new System.Drawing.Point(323, 453);
            this.btnDetener.Name = "btnDetener";
            this.btnDetener.Size = new System.Drawing.Size(113, 34);
            this.btnDetener.TabIndex = 9;
            this.btnDetener.Text = "Detener";
            this.btnDetener.UseVisualStyleBackColor = false;
            this.btnDetener.Click += new System.EventHandler(this.btnDetener_Click);
            // 
            // pictureBoxrojo2
            // 
            this.pictureBoxrojo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxrojo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxrojo2.Location = new System.Drawing.Point(176, 241);
            this.pictureBoxrojo2.Name = "pictureBoxrojo2";
            this.pictureBoxrojo2.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxrojo2.TabIndex = 10;
            this.pictureBoxrojo2.TabStop = false;
            this.pictureBoxrojo2.Click += new System.EventHandler(this.pictureBoxrojo2_Click);
            // 
            // pictureBoxamarillo2
            // 
            this.pictureBoxamarillo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxamarillo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxamarillo2.Location = new System.Drawing.Point(176, 284);
            this.pictureBoxamarillo2.Name = "pictureBoxamarillo2";
            this.pictureBoxamarillo2.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxamarillo2.TabIndex = 11;
            this.pictureBoxamarillo2.TabStop = false;
            // 
            // pictureBoxverde2
            // 
            this.pictureBoxverde2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxverde2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxverde2.Location = new System.Drawing.Point(176, 328);
            this.pictureBoxverde2.Name = "pictureBoxverde2";
            this.pictureBoxverde2.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxverde2.TabIndex = 12;
            this.pictureBoxverde2.TabStop = false;
            // 
            // btnApagar
            // 
            this.btnApagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnApagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApagar.Location = new System.Drawing.Point(580, 453);
            this.btnApagar.Name = "btnApagar";
            this.btnApagar.Size = new System.Drawing.Size(103, 34);
            this.btnApagar.TabIndex = 13;
            this.btnApagar.Text = "Apagar";
            this.btnApagar.UseVisualStyleBackColor = false;
            this.btnApagar.Click += new System.EventHandler(this.btnApagar_Click);
            // 
            // txtRojo
            // 
            this.txtRojo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtRojo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRojo.Location = new System.Drawing.Point(475, 294);
            this.txtRojo.Name = "txtRojo";
            this.txtRojo.Size = new System.Drawing.Size(100, 22);
            this.txtRojo.TabIndex = 14;
            // 
            // txtAmarillo
            // 
            this.txtAmarillo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAmarillo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAmarillo.Location = new System.Drawing.Point(475, 327);
            this.txtAmarillo.Name = "txtAmarillo";
            this.txtAmarillo.Size = new System.Drawing.Size(100, 22);
            this.txtAmarillo.TabIndex = 15;
            // 
            // txtVerde
            // 
            this.txtVerde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtVerde.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVerde.Location = new System.Drawing.Point(475, 360);
            this.txtVerde.Name = "txtVerde";
            this.txtVerde.Size = new System.Drawing.Size(100, 22);
            this.txtVerde.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(310, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 18);
            this.label1.TabIndex = 17;
            this.label1.Text = "Tiempo Rojo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(310, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 18);
            this.label2.TabIndex = 18;
            this.label2.Text = "Tiempo Amarillo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(310, 362);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 18);
            this.label3.TabIndex = 19;
            this.label3.Text = "Tiempo Verde";
            // 
            // pictureBoxSemaforo1
            // 
            this.pictureBoxSemaforo1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSemaforo1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSemaforo1.BackgroundImage")));
            this.pictureBoxSemaforo1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSemaforo1.Location = new System.Drawing.Point(278, 94);
            this.pictureBoxSemaforo1.Name = "pictureBoxSemaforo1";
            this.pictureBoxSemaforo1.Size = new System.Drawing.Size(90, 142);
            this.pictureBoxSemaforo1.TabIndex = 20;
            this.pictureBoxSemaforo1.TabStop = false;
            // 
            // pictureBoxSemaforo2
            // 
            this.pictureBoxSemaforo2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSemaforo2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSemaforo2.BackgroundImage")));
            this.pictureBoxSemaforo2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSemaforo2.Location = new System.Drawing.Point(150, 226);
            this.pictureBoxSemaforo2.Name = "pictureBoxSemaforo2";
            this.pictureBoxSemaforo2.Size = new System.Drawing.Size(90, 142);
            this.pictureBoxSemaforo2.TabIndex = 21;
            this.pictureBoxSemaforo2.TabStop = false;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(457, 453);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(102, 34);
            this.btnLimpiar.TabIndex = 22;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // pictureBoxverde3
            // 
            this.pictureBoxverde3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxverde3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxverde3.Location = new System.Drawing.Point(646, 372);
            this.pictureBoxverde3.Name = "pictureBoxverde3";
            this.pictureBoxverde3.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxverde3.TabIndex = 25;
            this.pictureBoxverde3.TabStop = false;
            // 
            // pictureBoxamarillo3
            // 
            this.pictureBoxamarillo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxamarillo3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxamarillo3.Location = new System.Drawing.Point(646, 328);
            this.pictureBoxamarillo3.Name = "pictureBoxamarillo3";
            this.pictureBoxamarillo3.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxamarillo3.TabIndex = 24;
            this.pictureBoxamarillo3.TabStop = false;
            // 
            // pictureBoxrojo3
            // 
            this.pictureBoxrojo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxrojo3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxrojo3.Location = new System.Drawing.Point(646, 284);
            this.pictureBoxrojo3.Name = "pictureBoxrojo3";
            this.pictureBoxrojo3.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxrojo3.TabIndex = 23;
            this.pictureBoxrojo3.TabStop = false;
            // 
            // pictureBoxSemaforo3
            // 
            this.pictureBoxSemaforo3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSemaforo3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSemaforo3.BackgroundImage")));
            this.pictureBoxSemaforo3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSemaforo3.Location = new System.Drawing.Point(621, 269);
            this.pictureBoxSemaforo3.Name = "pictureBoxSemaforo3";
            this.pictureBoxSemaforo3.Size = new System.Drawing.Size(88, 147);
            this.pictureBoxSemaforo3.TabIndex = 26;
            this.pictureBoxSemaforo3.TabStop = false;
            // 
            // pictureBoxverde4
            // 
            this.pictureBoxverde4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxverde4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxverde4.Location = new System.Drawing.Point(554, 197);
            this.pictureBoxverde4.Name = "pictureBoxverde4";
            this.pictureBoxverde4.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxverde4.TabIndex = 29;
            this.pictureBoxverde4.TabStop = false;
            // 
            // pictureBoxamarillo4
            // 
            this.pictureBoxamarillo4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxamarillo4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxamarillo4.Location = new System.Drawing.Point(554, 153);
            this.pictureBoxamarillo4.Name = "pictureBoxamarillo4";
            this.pictureBoxamarillo4.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxamarillo4.TabIndex = 28;
            this.pictureBoxamarillo4.TabStop = false;
            // 
            // pictureBoxrojo4
            // 
            this.pictureBoxrojo4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBoxrojo4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxrojo4.Location = new System.Drawing.Point(554, 110);
            this.pictureBoxrojo4.Name = "pictureBoxrojo4";
            this.pictureBoxrojo4.Size = new System.Drawing.Size(37, 38);
            this.pictureBoxrojo4.TabIndex = 27;
            this.pictureBoxrojo4.TabStop = false;
            // 
            // pictureBoxSemaforo4
            // 
            this.pictureBoxSemaforo4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSemaforo4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSemaforo4.BackgroundImage")));
            this.pictureBoxSemaforo4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxSemaforo4.Location = new System.Drawing.Point(528, 95);
            this.pictureBoxSemaforo4.Name = "pictureBoxSemaforo4";
            this.pictureBoxSemaforo4.Size = new System.Drawing.Size(90, 142);
            this.pictureBoxSemaforo4.TabIndex = 30;
            this.pictureBoxSemaforo4.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(275, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 31;
            this.label4.Text = "Semáforo1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(523, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 18);
            this.label5.TabIndex = 32;
            this.label5.Text = "Semáforo4";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(618, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 18);
            this.label6.TabIndex = 33;
            this.label6.Text = "Semáforo3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(149, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 18);
            this.label7.TabIndex = 34;
            this.label7.Text = "Semáforo2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 512);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBoxverde4);
            this.Controls.Add(this.pictureBoxamarillo4);
            this.Controls.Add(this.pictureBoxrojo4);
            this.Controls.Add(this.pictureBoxSemaforo4);
            this.Controls.Add(this.pictureBoxverde3);
            this.Controls.Add(this.pictureBoxamarillo3);
            this.Controls.Add(this.pictureBoxrojo3);
            this.Controls.Add(this.pictureBoxSemaforo3);
            this.Controls.Add(this.pictureBoxverde2);
            this.Controls.Add(this.pictureBoxamarillo2);
            this.Controls.Add(this.pictureBoxrojo2);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.pictureBoxSemaforo2);
            this.Controls.Add(this.pictureBoxverde1);
            this.Controls.Add(this.pictureBoxamarillo1);
            this.Controls.Add(this.pictureBoxrojo1);
            this.Controls.Add(this.pictureBoxSemaforo1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtVerde);
            this.Controls.Add(this.txtAmarillo);
            this.Controls.Add(this.txtRojo);
            this.Controls.Add(this.btnApagar);
            this.Controls.Add(this.btnDetener);
            this.Controls.Add(this.btnIniciar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxverde4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxamarillo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxrojo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSemaforo4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBoxrojo1;
        private System.Windows.Forms.PictureBox pictureBoxamarillo1;
        private System.Windows.Forms.PictureBox pictureBoxverde1;
        private System.Windows.Forms.Button btnIniciar;
        private System.Windows.Forms.Button btnDetener;
        private System.Windows.Forms.PictureBox pictureBoxrojo2;
        private System.Windows.Forms.PictureBox pictureBoxamarillo2;
        private System.Windows.Forms.PictureBox pictureBoxverde2;
        private System.Windows.Forms.Button btnApagar;
        private System.Windows.Forms.TextBox txtRojo;
        private System.Windows.Forms.TextBox txtAmarillo;
        private System.Windows.Forms.TextBox txtVerde;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBoxSemaforo1;
        private System.Windows.Forms.PictureBox pictureBoxSemaforo2;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.PictureBox pictureBoxverde3;
        private System.Windows.Forms.PictureBox pictureBoxamarillo3;
        private System.Windows.Forms.PictureBox pictureBoxrojo3;
        private System.Windows.Forms.PictureBox pictureBoxSemaforo3;
        private System.Windows.Forms.PictureBox pictureBoxverde4;
        private System.Windows.Forms.PictureBox pictureBoxamarillo4;
        private System.Windows.Forms.PictureBox pictureBoxrojo4;
        private System.Windows.Forms.PictureBox pictureBoxSemaforo4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

